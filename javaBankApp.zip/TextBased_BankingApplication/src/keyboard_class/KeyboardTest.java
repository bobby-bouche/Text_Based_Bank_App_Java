package keyboard_class;

public class KeyboardTest {
	
	public static void main(String[] args) {
		
		Keyboard kb = new Keyboard();
		
		int intInput;
		String promptMsg1 = "Enter an integer value: ";
		String errorMsg1 = "Invalid entry, enter an integer value from the menu";
		
		intInput = kb.readInteger(promptMsg1, errorMsg1);
		
		System.out.println("You entered the value: " + intInput);
		
		//--------------------------------------------------------------
		int intInput2;
		String promptMsg2 = "Enter an integer value in the range (1-10): ";
		String errorMsg2 = "Invalid entry, enter an integer value in the range(1-10)";
		
		intInput2 = kb.readInteger(promptMsg2, errorMsg2, 1, 10);
		
		System.out.println("You entered the value: " + intInput2);
	}

}
